CREATE PROCEDURE sp_tasks_save(IN pidtask   INT, IN pidproject INT, IN pdestask VARCHAR(128), IN pdtstart TIMESTAMP,
                               IN pdtfinish TIMESTAMP, IN psttask TINYINT)
  BEGIN
	
	IF pidtask > 0 THEN
		
		UPDATE tb_tasks
        SET 
			idproject = pidproject,
            destask = pdestask,
            dtstart = pdtstart,
            dtfinish = pdtfinish,
            sttask = psttask
        WHERE idtask = pidtask;
        
    ELSE
		
		INSERT INTO tb_tasks (idproject, destask, dtstart, dtfinish, sttask) 
        VALUES(pidproject, pdestask, pdtstart, pdtfinish, 0);
        
        SET pidtask = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_tasks WHERE idtask = pidtask;
    
END;
