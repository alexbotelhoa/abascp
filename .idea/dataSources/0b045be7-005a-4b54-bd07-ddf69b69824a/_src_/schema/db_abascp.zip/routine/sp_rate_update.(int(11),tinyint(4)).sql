CREATE PROCEDURE sp_rate_update(IN pidproject INT, IN prtproject TINYINT)
  BEGIN

	UPDATE tb_projects
	SET rtproject = prtproject
	WHERE idproject = pidproject;
        
END;
