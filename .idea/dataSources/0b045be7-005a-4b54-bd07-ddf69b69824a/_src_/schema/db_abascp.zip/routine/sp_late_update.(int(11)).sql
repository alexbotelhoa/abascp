CREATE PROCEDURE sp_late_update(IN pidproject INT)
  BEGIN
  
    DECLARE vstproject INT;
    
	SELECT IF (a.dtfinish >= max(b.dtfinish), 0, 1) INTO vstproject
	FROM tb_projects a 
	INNER JOIN tb_tasks b USING(idproject)
    WHERE a.idproject = pidproject
	GROUP BY a.idproject;
    
    UPDATE tb_projects
    SET stproject = vstproject
	WHERE idproject = pidproject;
     
END;
