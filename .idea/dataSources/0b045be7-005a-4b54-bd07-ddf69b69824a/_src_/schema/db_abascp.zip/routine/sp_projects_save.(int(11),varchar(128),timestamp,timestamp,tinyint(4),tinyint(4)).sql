CREATE PROCEDURE sp_projects_save(IN pidproject INT, IN pdesproject VARCHAR(128), IN pdtstart TIMESTAMP, IN pdtfinish TIMESTAMP, IN prtproject TINYINT, IN pstproject TINYINT)
  BEGIN
	
	IF pidproject > 0 THEN
		
		UPDATE tb_projects
        SET 
			desproject = pdesproject,
            dtstart = pdtstart,
            dtfinish = pdtfinish,
            rtproject = prtproject,
            stproject = pstproject
        WHERE idproject = pidproject;
        
    ELSE
		
		INSERT INTO tb_projects (desproject, dtstart, dtfinish, rtproject, stproject) 
        VALUES(pdesproject, pdtstart, pdtfinish, 0, 0);
        
        SET pidproject = LAST_INSERT_ID();
        
    END IF;
    
    SELECT * FROM tb_projects WHERE idproject = pidproject;
    
END;
